package mx.edu.utez.voluntariapp1.controllers.user;


import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;
import mx.edu.utez.voluntariapp1.models.Role.Role;
import mx.edu.utez.voluntariapp1.models.user.DaoUser;
import mx.edu.utez.voluntariapp1.models.user.User;

import java.io.IOException;
import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;
import java.sql.SQLException;

import static java.lang.Long.parseLong;

@WebServlet(name = "users",urlPatterns = {
        "/user/users",
        "/user/user",
        "/user/login",
        "/user/user-view",
        "/user/main",
        "/user/save",
        "/user/save-view",
        "/user/user-view-update",
        "/user/update",
        "/user/delete",
})

public class ServletUser extends HttpServlet {

    public String action;
    private String redirect = "/user/main";
    User user;
    HttpSession session;
    private String id_role;
    private String id_user,email,password,is_active;


    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        req.setCharacterEncoding("UTF-8");
        action = req.getServletPath();
        switch (action){
            case "/user/main": //redirigir al inicio
                redirect = "/pages/administrators/index_admin.jsp";
                break;
            case "/user/save-view":
                req.setAttribute("roles",new DaoUser().searchRole());
                redirect = "/pages/create_administrator_account.jsp";
                break;
            case "/user/user-view":
                redirect = "/pages/administrators/administrator_porfile.jsp";
                break;
            case "/user/login":
                redirect = "/index.jsp";
                break;
//            default:
//                System.out.println(action);
//                break;
            case "/user/role": //redirigir al inicio
                redirect = "/pages/register_login.jsp";
                break;
        }
        req.getRequestDispatcher(redirect).forward(req, resp);
    }
    /*Termina el metodo DOGET*/

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        req.setCharacterEncoding("UTF-8");
        resp.setCharacterEncoding("UTF-8");
        resp.setContentType("text/html");
        action = req.getServletPath();
        switch (action){
            case "/user/main":
                email = req.getParameter("email");
                password = req.getParameter("password");
                System.out.println(email+password);
                try {
                    user = new DaoUser().loadUserByEmailandPassword(email, password);
                    if (user != null) {
                        session = req.getSession();
                        session.setAttribute("user", user);
                        switch (user.getDescription().getDescription()) {
                            case "ADMIN":
                                redirect = "/user/main";
                                break;
                            case "ORGANIZATION":
                                redirect = "/organization/main";
                                break;
                            case "VOLUNTEER":
                                redirect = "/volunteer/main";
                                break;
                        }
                    } else {
                        throw new Exception("Credentials mismatch");
                    }
                } catch (Exception e) {
                    redirect = "/user/login?result=false&message=" + URLEncoder
                            .encode("Email y/o contraseña incorrecta",
                                    StandardCharsets.UTF_8);
                }
                break;
            case "/user/save":
                email = req.getParameter("email");
                password = req.getParameter("password");

                id_role = req.getParameter("roleId");
                Role role = new Role();
                role.setId(parseLong(id_role));

                User user1 = new User(0L, email, password,"0", role);
                boolean result = false;
                try {
                    result = new DaoUser().save(user1);
                } catch (SQLException e) {
                    throw new RuntimeException(e);
                }
                if (result) {
                    redirect = "/user/users?result= " + result + "&message=" + URLEncoder.encode("!Éxito! Usuario registrado correctamente.", StandardCharsets.UTF_8);
                } else {
                    redirect = "user/users?result= " + result + "&message=" + URLEncoder.encode("!No Éxito! Usuario no registrado correctamente.", StandardCharsets.UTF_8);
                }
                break;
        }
        resp.sendRedirect(req.getContextPath()
                + redirect);
    }
}
