package mx.edu.utez.voluntariapp1.models.Role;

public class Role {
    private Long id_role;
    private String description;

    public Role() {
    }

    public Role(Long id_role, String description) {
        this.id_role = id_role;
        this.description = description;
    }

    public Long getId_role() {return id_role;}

    public void setId(Long id_role) {this.id_role = id_role;}

    public String getDescription() {return description;}

    public void setRole(String description) {this.description = description;}

}
