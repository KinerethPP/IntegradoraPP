package mx.edu.utez.voluntariapp1.models.crud;

import mx.edu.utez.voluntariapp1.models.Role.Role;

import java.sql.SQLException;
import java.util.List;

public interface DaoRepository<T>{

    List<T> findAll();
    T finOne(Long id);
    boolean save(T object) throws SQLException;

    List<Role> searchRole();

    boolean update(T object);
    boolean delete(Long id);


}
